﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public class Settings
    {
        private static Settings instance;

        public static Settings Instance
        {
            get
            {
                instance ??= new();
                return instance;
            }
        }

        public Color SelectedColor { get; set; } = Color.Black;
        public float PenWidth { get; set; } = 2.0f;
        public Font Font { get; set; } = new Font("Arial", 12);
        public ShapeType CurrentShape { get; set; }
        public string Text { get; set; } = "Valami";

        private Settings()
        {
            
        }
    }
}
