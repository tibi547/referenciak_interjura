﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public enum ShapeType
    {
        Line, Circle, Rectangle, Text
    }
}
