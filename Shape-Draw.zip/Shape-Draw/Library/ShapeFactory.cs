﻿using shape_drawer.Shape_Strategy;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public static class ShapeFactory
    {
        public static IShape CreateShape(ShapeType type, Point start, Point end)
        {
            var s = Settings.Instance;
            
            switch (type)
            {
                case ShapeType.Line:
                    return new LineShape(start, end);
                case ShapeType.Circle:
                    return new CircleShape(start, end);
                case ShapeType.Rectangle:
                    return new RectangleShape(start, end);
                case ShapeType.Text:
                    return new TextShape(end);
            }

            throw new Exception("Invalid shape");
        }
    }
}
