﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer.Shape_Strategy
{
    public class TextShape : IShape
    {
        private string s;
        private PointF pointF;
        private Font font;
        private Color color;

        public TextShape(PointF pointF)
        {
            this.s = Settings.Instance.Text;
            this.pointF = pointF;
            this.font = Settings.Instance.Font;
            this.color = Settings.Instance.SelectedColor;
        }

        public void Draw(Graphics g)
        {
            using (SolidBrush brush = new SolidBrush(color))
            {
                g.DrawString(s, font, brush, pointF);
            }
        }
    }
}
