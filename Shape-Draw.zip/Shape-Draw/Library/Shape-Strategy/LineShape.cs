﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer.Shape_Strategy
{
    public class LineShape : IShape
    {
        private Point pointA;
        private Point pointB;
        private Color color;
        private float penWidth;

        public LineShape(Point pointA, Point pointB)
        {
            this.pointA = pointA;
            this.pointB = pointB;
            this.color = Settings.Instance.SelectedColor;
            this.penWidth = Settings.Instance.PenWidth;
        }

        public void Draw(Graphics g)
        {
            using (Pen pen = new Pen(color, penWidth))
            {
                g.DrawLine(pen, pointA, pointB);
            }
        }
    }
}
