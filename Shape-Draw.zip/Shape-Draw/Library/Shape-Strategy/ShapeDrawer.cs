﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public class ShapeDrawer
    {
        private readonly List<IShape> shapes;

        public ShapeDrawer()
        {
            shapes = new();
        }

        public void AddShape(IShape shape)
        {
            if (!shapes.Contains(shape))
                shapes.Add(shape);
        }

        public void RemoveShape(IShape shape)
        {
            if (shapes.Contains(shape))
                shapes.Remove(shape);
        }

        public IEnumerable<IShape> Shapes
        {
            get
            {
                return shapes;
            }
        }

        public void DrawAll(Graphics g)
        {
            if (shapes.Count > 0)
            {
                foreach (var shape in shapes)
                {
                    shape.Draw(g);
                }
            }
        }
    }
}
