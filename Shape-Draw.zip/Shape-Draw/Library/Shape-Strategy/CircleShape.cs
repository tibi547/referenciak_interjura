﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public class CircleShape : IShape
    {
        private float x;
        private float y;
        private float radius;
        private Color color;
        private float penWidth;

        public CircleShape(PointF start, PointF end)
        {
            this.x = start.X;
            this.y = start.Y;

            float dx = end.X - start.X;
            float dy = end.Y - start.Y;

            this.radius = (float)Math.Sqrt(dx * dx + dy * dy);
            this.color = Settings.Instance.SelectedColor;

            this.penWidth = Settings.Instance.PenWidth;
        }

        public void Draw(Graphics g)
        {
            using (Pen pen = new Pen(color, penWidth))
            {
                g.DrawEllipse(pen, x - radius, y - radius, radius * 2, radius * 2);
            }
        }
    }
}
