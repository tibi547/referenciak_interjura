﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public class RectangleShape : IShape
    {
        private float x;
        private float y;
        private float width;
        private float height;
        private Color color;
        private float penWidth;

        public RectangleShape(PointF p1, PointF p2)
        {
            this.x = Math.Min(p1.X, p2.X);
            this.y = Math.Min(p1.Y, p2.Y);

            this.width = Math.Abs(p1.X - p2.X);
            this.height = Math.Abs(p1.Y - p2.Y);
            this.color = Settings.Instance.SelectedColor;

            this.penWidth = Settings.Instance.PenWidth;
        }

        public void Draw(Graphics g)
        {
            using (Pen pen = new Pen(color, penWidth))
            {
                g.DrawRectangle(pen, x, y, width, height);
            }
        }
    }
}
