﻿using shape_drawer.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public class DeleteShapeCommand : ICommand
    {
        private readonly List<IShape> shapes;
        private readonly IShape shape;
        private readonly int index;

        public DeleteShapeCommand(List<IShape> shapes, IShape shape)
        {
            this.shapes = shapes;
            this.shape = shape;
            this.index = shapes.IndexOf(shape);
        }

        public void Undo()
        {
            shapes.Insert(index, shape);
        }

        public void Execute()
        {
            shapes.Remove(shape);
        }
    }
}
