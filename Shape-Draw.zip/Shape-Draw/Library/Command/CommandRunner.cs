﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public class CommandRunner
    {
        private readonly Stack<ICommand> history;
        private readonly Stack<ICommand> redoStack;

        public CommandRunner()
        {
            history = new();
            redoStack = new();
        }

        public void ExecuteCommand(ICommand command)
        {
            command.Execute();
            history.Push(command);
            redoStack.Clear(); 
        }

        public void Undo()
        {
            if (history.Count > 0)
            {
                var command = history.Pop();
                command.Undo();
                redoStack.Push(command);
            }
        }

        public void Redo()
        {
            if (redoStack.Count > 0)
            {
                var command = redoStack.Pop();
                command.Execute();
                history.Push(command);
            }
        }
    }
}
