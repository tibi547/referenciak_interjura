﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer.Command
{
    public class ClearCanvasCommand : ICommand
    {
        private readonly ShapeDrawer drawer;
        private List<IShape> backup;

        public ClearCanvasCommand(ShapeDrawer drawer)
        {
            this.drawer = drawer;
        }

        public void Execute()
        {
            backup = new List<IShape>(drawer.Shapes);
            foreach (var s in backup) 
            {
                drawer.RemoveShape(s);
            } 
        }

        public void Undo()
        {
            foreach (var s in backup)
            {
                drawer.AddShape(s);
            }
        }
    }
}
