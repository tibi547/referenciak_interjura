﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shape_drawer
{
    public class AddShapeCommand : ICommand
    {
        private readonly List<IShape> shapes;
        private readonly IShape shape;        

        public AddShapeCommand(List<IShape> shapes, IShape shape)
        {
            this.shapes = shapes;
            this.shape = shape;
        }

        public void Execute()
        {
            shapes.Add(shape); 
        }

        public void Undo()
        {
            shapes.Remove(shape); 
        }
    }
}
