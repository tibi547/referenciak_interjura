using shape_drawer;
using shape_drawer.Command;
using shape_drawer.Shape_Strategy;

namespace Shape_Draw
{
    public partial class Form1 : Form
    {
        public ShapeDrawer shapeDrawer = new();
        public CommandRunner commandRunner = new();
        public Settings settings = Settings.Instance;
        private Point start;
        public Form1()
        {
            InitializeComponent();
            LoadBoxes();
        }

        private void LoadBoxes()
        {
            cmbShapes.Items.AddRange(new object[] { "Line", "Text", "Circle", "Rectangle" });
            cmbShapes.SelectedIndex = 0;

            cmbColors.Items.AddRange(new object[] { "Black", "Red", "Blue", "Green" });
            cmbColors.SelectedIndex = 0;

            cmbWidth.Items.AddRange(new object[] { 2.0f, 4.0f, 8.0f, 12.0f });
            cmbWidth.SelectedIndex = 0;

            cmbFonts.Items.AddRange(new object[] { "Arial", "Times New Roman", "Verdana" });
            cmbFonts.SelectedIndex = 0;
        }

        private void paintBox_Paint(object sender, PaintEventArgs e)
        {
            shapeDrawer.DrawAll(e.Graphics);
        }

        private void paintBox_MouseUp(object sender, MouseEventArgs e)
        {
            ShapeType type = settings.CurrentShape;
            IShape newShape = ShapeFactory.CreateShape(type, start, e.Location);
            ICommand cmd = new AddShapeCommand((List<IShape>)shapeDrawer.Shapes, newShape);
            commandRunner.ExecuteCommand(cmd);
            paintBox.Invalidate();
        }

        private void paintBox_MouseDown(object sender, MouseEventArgs e)
        {
            start = e.Location;
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            commandRunner.Undo();
            paintBox.Invalidate();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ICommand cmd = new ClearCanvasCommand(shapeDrawer);
            commandRunner.ExecuteCommand(cmd);
            paintBox.Invalidate();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.Z))
            {
                commandRunner.Undo();
                paintBox.Invalidate();
                return true;
            }

            if (keyData == (Keys.Control | Keys.Y))
            {
                commandRunner.Redo();
                paintBox.Invalidate();
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void btnRedo_Click(object sender, EventArgs e)
        {
            commandRunner.Redo();
            paintBox.Invalidate();
        }


        private void txtBox_TextChanged(object sender, EventArgs e)
        {
            settings.Text = txtBox.Text;
        }

        private void cmbShapes_SelectedIndexChanged(object sender, EventArgs e)
        {
            settings.CurrentShape = (ShapeType)Enum.Parse(typeof(ShapeType), cmbShapes.SelectedItem.ToString());
        }

        private void cmbColors_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = cmbColors.SelectedItem.ToString();
            settings.SelectedColor = Color.FromName(selected);
        }

        private void cmbWidth_SelectedIndexChanged(object sender, EventArgs e)
        {
            settings.PenWidth = (float)cmbWidth.SelectedItem;
        }

        private void cmbFonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            settings.Font = new Font(cmbFonts.SelectedItem.ToString(), 12);
        }
    }
}
