﻿namespace Shape_Draw
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            paintBox = new PictureBox();
            btnUndo = new Button();
            btnClear = new Button();
            btnRedo = new Button();
            txtBox = new TextBox();
            cmbShapes = new ComboBox();
            cmbColors = new ComboBox();
            cmbWidth = new ComboBox();
            cmbFonts = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)paintBox).BeginInit();
            SuspendLayout();
            // 
            // paintBox
            // 
            paintBox.Location = new Point(-73, 12);
            paintBox.Name = "paintBox";
            paintBox.Size = new Size(986, 695);
            paintBox.TabIndex = 0;
            paintBox.TabStop = false;
            paintBox.Paint += paintBox_Paint;
            paintBox.MouseDown += paintBox_MouseDown;
            paintBox.MouseUp += paintBox_MouseUp;
            // 
            // btnUndo
            // 
            btnUndo.Location = new Point(919, 636);
            btnUndo.Name = "btnUndo";
            btnUndo.Size = new Size(112, 34);
            btnUndo.TabIndex = 5;
            btnUndo.Text = "Undo";
            btnUndo.UseVisualStyleBackColor = true;
            btnUndo.Click += btnUndo_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(1155, 636);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(112, 34);
            btnClear.TabIndex = 6;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btnRedo
            // 
            btnRedo.Location = new Point(1037, 636);
            btnRedo.Name = "btnRedo";
            btnRedo.Size = new Size(112, 34);
            btnRedo.TabIndex = 7;
            btnRedo.Text = "Redo";
            btnRedo.UseVisualStyleBackColor = true;
            btnRedo.Click += btnRedo_Click;
            // 
            // txtBox
            // 
            txtBox.Location = new Point(919, 676);
            txtBox.Name = "txtBox";
            txtBox.Size = new Size(348, 31);
            txtBox.TabIndex = 12;
            txtBox.TextChanged += txtBox_TextChanged;
            // 
            // cmbShapes
            // 
            cmbShapes.FormattingEnabled = true;
            cmbShapes.Location = new Point(981, 82);
            cmbShapes.Name = "cmbShapes";
            cmbShapes.Size = new Size(182, 33);
            cmbShapes.TabIndex = 13;
            cmbShapes.SelectedIndexChanged += cmbShapes_SelectedIndexChanged;
            // 
            // cmbColors
            // 
            cmbColors.FormattingEnabled = true;
            cmbColors.Location = new Point(981, 121);
            cmbColors.Name = "cmbColors";
            cmbColors.Size = new Size(182, 33);
            cmbColors.TabIndex = 14;
            cmbColors.SelectedIndexChanged += cmbColors_SelectedIndexChanged;
            // 
            // cmbWidth
            // 
            cmbWidth.FormattingEnabled = true;
            cmbWidth.Location = new Point(981, 160);
            cmbWidth.Name = "cmbWidth";
            cmbWidth.Size = new Size(182, 33);
            cmbWidth.TabIndex = 15;
            cmbWidth.SelectedIndexChanged += cmbWidth_SelectedIndexChanged;
            // 
            // cmbFonts
            // 
            cmbFonts.FormattingEnabled = true;
            cmbFonts.Location = new Point(981, 199);
            cmbFonts.Name = "cmbFonts";
            cmbFonts.Size = new Size(182, 33);
            cmbFonts.TabIndex = 16;
            cmbFonts.SelectedIndexChanged += cmbFonts_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1279, 719);
            Controls.Add(cmbFonts);
            Controls.Add(cmbWidth);
            Controls.Add(cmbColors);
            Controls.Add(cmbShapes);
            Controls.Add(txtBox);
            Controls.Add(btnRedo);
            Controls.Add(btnClear);
            Controls.Add(btnUndo);
            Controls.Add(paintBox);
            DoubleBuffered = true;
            Name = "Form1";
            Text = "Shape-Drawer";
            ((System.ComponentModel.ISupportInitialize)paintBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox paintBox;
        
        private Button btnUndo;
        private Button btnClear;
        private Button btnRedo;
        
        private TextBox txtBox;
        private ComboBox cmbShapes;
        private ComboBox cmbColors;
        private ComboBox cmbWidth;
        private ComboBox cmbFonts;
    }
}
