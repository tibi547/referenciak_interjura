<?php
require_once "../db.php";

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents('php://input'), true);

switch($method){
    case 'GET':
        if (isset($_GET['worst'])) {
        echo getWorstRating($conn);
        } else if (isset($_GET['best'])) {
        echo getBestRating($conn); 
        } else if (isset($_GET['id'])) {
        echo getReview($conn, $_GET['id']);
        } else {
        echo getReviews($conn);
        }
        break;
    case 'POST':
        echo createReview($conn, $data);
        break;
    case 'PUT':
        echo updateReview($conn, $data);
        break;
    case 'DELETE':
        if (!isset($data["id"])) {
            http_response_code(400);
            echo json_encode(["message" => "Missing id"]);
            exit;
        }
        $id = $data["id"];
        echo deleteReview($conn, $id);
        break;
    default:
        http_response_code(405);
        echo json_encode(array('message' => 'Method not allowed'));
        break;
}

function getReviews($conn){
    $sql = "SELECT r.id, u.username, a.title, r.rating, r.message 
            FROM reviews r
            INNER JOIN users u ON r.user_id = u.id
            INNER JOIN animes a ON r.anime_id = a.id";
    $result = $conn->query($sql);
    $reviews = array();
    while($row = $result->fetch_assoc()){
        $reviews[] = $row;
    }
    return json_encode($reviews);
}

function getReview($conn, $id){
    $sql = $conn->prepare("SELECT * FROM reviews WHERE id = ?");
    $sql->bind_param('i', $id);
    $sql->execute();
    $result = $sql->get_result();

    if($result->num_rows > 0){
        $rew = $result->fetch_assoc();
        return json_encode($rew);
    }
    else {
        http_response_code(404);
        return json_encode(array("message" => "Review not found"));
    }
}

function getWorstRating($conn){
    $sql = "SELECT a.title, r.rating, r.message 
            FROM reviews r 
            INNER JOIN animes a ON a.id = r.anime_id 
            ORDER BY r.rating ASC LIMIT 1";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $rew = $result->fetch_assoc();
        return json_encode($rew);
    } else {
        http_response_code(404);
        return json_encode(array("message" => "No reviews found"));
    }
}

function getBestRating($conn){
    $sql = "SELECT a.title, r.rating, r.message 
            FROM reviews r 
            INNER JOIN animes a ON a.id = r.anime_id 
            ORDER BY r.rating DESC LIMIT 1";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $rew = $result->fetch_assoc();
        return json_encode($rew);
    } else {
        http_response_code(404);
        return json_encode(array("message" => "No reviews found"));
    }
}

function createReview($conn, $data){
    if (!isset($data['user_id'], $data['anime_id'], $data['rating'], $data['message'])) {
        http_response_code(400);
        return json_encode(array("message" => "Missing required fields"));
    }

    if (!is_numeric($data['user_id']) || !is_numeric($data['anime_id']) || !is_numeric($data['rating'])) {
        http_response_code(400);
        return json_encode(array("message" => "Must send numeric id/rating"));
    }

    $userid = $data['user_id'];
    $animeid = $data['anime_id'];
    $rating = $data['rating'];
    $message = $data['message'];

    $stmt = $conn->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->bind_param('i', $userid);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        return json_encode(["message" => "User not found"]);
    }

    $stmt = $conn->prepare("SELECT id FROM animes WHERE id = ?");
    $stmt->bind_param('i', $animeid);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        http_response_code(400);
        return json_encode(["message" => "Anime not found"]);
    }

    if ($rating < 1 || $rating > 5) {
        http_response_code(400);
        return json_encode(["message" => "Rating must be between 1 and 5"]);
    }

    if (strlen($message) > 255) {
        http_response_code(400);
        return json_encode(["message" => "Message too long (max 255 characters)"]);
    }

    $sql = $conn->prepare("INSERT INTO reviews (user_id, anime_id, rating, message) VALUES (?, ?, ?, ?)");
    $sql->bind_param('iiis', $userid, $animeid, $rating, $message);

    if ($sql->execute()) {
        $rew_id = $conn->insert_id;
        http_response_code(201);
        return json_encode(array("message" => "Review created successfully", "review_id" => $rew_id));
    } else {
        http_response_code(500);
        return json_encode(array("message" => "Error creating review", "error" => $sql->error));
    }
}

function updateReview($conn, $data){
    if(!isset($data['id']) || !is_numeric($data['id'])){
        http_response_code(400);
        return json_encode(array("message" => "Must send a valid numeric review id"));
    }

    $stmt = $conn->prepare("SELECT * FROM reviews WHERE id = ?");
    $stmt->bind_param('i', $data['id']);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 0){
        http_response_code(404);
        return json_encode(array("message" => "Review not found"));
    }

    $review = $result->fetch_assoc();

    $user_id = isset($data['user_id']) ? $data['user_id'] : $review['user_id'];
    $anime_id = isset($data['anime_id']) ? $data['anime_id'] : $review['anime_id'];
    $rating = isset($data['rating']) ? $data['rating'] : $review['rating'];
    $message = isset($data['message']) ? $data['message'] : $review['message'];

    $update = $conn->prepare("UPDATE reviews SET user_id = ?, anime_id = ?, rating = ?, message = ? WHERE id = ?");
    $update->bind_param('iiisi', $user_id, $anime_id, $rating, $message, $data['id']);

    if($update->execute()){
        return json_encode(array("message" => "Review updated"));
    } else {
        http_response_code(500);
        return json_encode(array("message" => "Error updating review", "error" => $update->error));
    }
}

function deleteReview($conn, $id){
    if(!is_numeric($id)){
        http_response_code(400);
        return json_encode(array("message" => "Invalid id"));
    }

    $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ?");
    $stmt->bind_param('i', $id);

    if($stmt->execute()){
        if($stmt->affected_rows > 0){
            return json_encode(array("message" => "Review deleted"));
        } else {
            http_response_code(404);
            return json_encode(array("message" => "Review not found"));
        }
    } else {
        http_response_code(500);
        return json_encode(array("message" => "Error deleting review", "error" => $stmt->error));
    }
}

?>