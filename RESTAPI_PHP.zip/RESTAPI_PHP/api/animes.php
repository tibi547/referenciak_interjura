<?php
require_once "../db.php";

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents('php://input'), true);

switch($method){
    case 'GET':
        if (isset($_GET['avg'])) {
        echo getAnimesAvgRating($conn);
        } else if (isset($_GET['genre'])) {
        echo getAnimesByGenre($conn, $_GET['genre']); }
         else if (isset($_GET['id'])) {
        echo getAnime($conn, $_GET['id']);
        } else {
        echo getAnimes($conn);
        }
        break;
    case 'POST':
        echo createAnime($conn, $data);
        break;
    case 'PUT':
        echo updateAnime($conn, $data);
        break;
    case 'DELETE':
        if (!isset($data["id"])) {
            http_response_code(400);
            echo json_encode(["message" => "Missing id"]);
            exit;
        }
        $id = $data["id"];
        echo deleteAnime($conn, $id);
        break;
    default:
        http_response_code(405);
        echo json_encode(array('message' => 'Method not allowed'));
        break;
    }    

function getAnimes($conn){
    $sql = "SELECT * FROM animes";
    $result = $conn->query($sql);
    $animes = array();
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $animes[] = $row;
        }
    }

    return json_encode($animes);
}

function getAnime($conn, $id){
    $sql = $conn->prepare("SELECT * FROM animes WHERE id = ?");
    $sql->bind_param('i', $id);
    $sql->execute();
    $result = $sql->get_result();

    if($result->num_rows > 0){
        $anime = $result->fetch_assoc();
        return json_encode($anime);
    }
    else {
        http_response_code(404);
        return json_encode(array("message" => "Anime not found"));
    }
}

function getAnimesAvgRating($conn){
    $sql = $conn->prepare("SELECT a.title, ROUND(AVG(r.rating),0) AS average
    FROM animes a INNER JOIN reviews r
    ON a.id = r.anime_id GROUP BY a.title");
    $sql->execute();

    $result = $sql->get_result();

    $rates = array();
    while($row = $result->fetch_assoc()) {
        $rates[] = $row;
    }

    if (count($rates) > 0) {
        return json_encode($rates);
    } else {
        http_response_code(404);
        return json_encode(array("message" => "No reviews found for this anime"));
    }
}

function getAnimesByGenre($conn, $genre) {
    $sql = $conn->prepare("SELECT a.title
    FROM animes a WHERE a.genre = ?"
    );
    $sql->bind_param('s', $genre);
    $sql->execute();

    $result = $sql->get_result();

    $animes = array();
    while($row = $result->fetch_assoc()) {
        $animes[] = $row;
    }

    if (count($animes) > 0) {
        return json_encode($animes);
    } else {
        http_response_code(404);
        return json_encode(array("message" => "No animes found for this genre"));
    }
}

function createAnime($conn, $data){
    if (!isset($data['title'], $data['genre'], $data['year'])) {
    http_response_code(400);
    return json_encode(array("message" => "Missing required fields"));
    }

    $title = $data['title'];
    $genre = $data['genre'];
    $year = $data['year'];
    $sql = $conn->prepare("INSERT INTO animes (title, genre, year) VALUES (?, ?, ?)");
    $sql->bind_param('sss', $title, $genre, $year);

    if($sql->execute()){
        $anime_id = $conn->insert_id;
        http_response_code(201);
        return json_encode(array("message" => "Anime created successfully", "anime_id" => $anime_id));
    }
    else {
        http_response_code(500);
        return json_encode(array("message" => "Error creating anime", "error" => $sql->error));
    }
}

function updateAnime($conn, $data){
    if(!isset($data['id']) || !is_numeric($data['id'])){
        http_response_code(400);
        return json_encode(array("message" => "Must send a valid numeric id"));
    }

    $sql = $conn->prepare("SELECT * FROM animes WHERE id = ?");
    $sql->bind_param('i', $data['id']);
    $sql->execute();
    $result = $sql->get_result();

    if($result->num_rows == 0){
        http_response_code(404);
        return json_encode(array("message" => "Anime not found"));
    }

    $anime = $result->fetch_assoc();

    $title = isset($data['title']) ? $data['title'] : $anime['title'];
    $genre = isset($data['genre']) ? $data['genre'] : $anime['genre'];
    $year = isset($data['year']) ? $data['year'] : $anime['year'];

    $update = $conn->prepare("UPDATE animes SET title = ?, genre = ?, year = ? WHERE id = ?");
    $update->bind_param('sssi', $title, $genre, $year, $data['id']);

    if($update->execute()){
        return json_encode(array("message" => "Anime updated"));
    } else {
        http_response_code(500);
        return json_encode(array("message" => "Error updating anime", "error" => $update->error));
    }
}

function deleteAnime($conn, $id){
    if(!is_numeric($id)){
        http_response_code(400);
        return json_encode(array("message" => "Invalid id"));
    }

    $stmt = $conn->prepare("DELETE FROM animes WHERE id = ?");
    $stmt->bind_param('i', $id);

    if($stmt->execute()){
        if($stmt->affected_rows > 0){
            return json_encode(array("message" => "Anime deleted"));
        } else {
            http_response_code(404);
            return json_encode(array("message" => "Anime not found"));
        }
    } else {
        http_response_code(500);
        return json_encode(array("message" => "Error deleting anime", "error" => $stmt->error));
    }
}

?>