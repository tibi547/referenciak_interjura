<?php
require_once "../db.php";

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents('php://input'), true);

switch($method){
    case 'GET':
        if (isset($_GET['user_id']) && isset($_GET['reviews'])) {
        echo getUserReviews($conn, $_GET['user_id']);
        } else if (isset($_GET['active'])) {
        echo getActiveUsers($conn); 
        } else if (isset($_GET['user_id'])) {
        echo getUser($conn, $_GET['user_id']);
        } else {
        echo getUsers($conn);
        }
        break;
    case 'POST':
        echo createUser($conn, $data);
        break;
    case 'PUT':
        echo updateUser($conn, $data);
        break;
    case 'DELETE':
        if (!isset($data["id"])) {
            http_response_code(400);
            echo json_encode(["message" => "Missing id"]);
            exit;
        }
        $id = $data["id"];
        echo deleteUser($conn, $id);
        break;
    default:
        http_response_code(405);
        echo json_encode(array('message' => 'Method not allowed'));
        break;
}

function getUsers($conn){
    $sql = "SELECT id, username FROM users";
    $result = $conn->query($sql);
    $users = array();
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $users[] = $row;
        }
    }

    return json_encode($users);
}

function getUser($conn, $id){
    $sql = $conn->prepare("SELECT id, username FROM users WHERE id = ?");
    $sql->bind_param('i', $id);
    $sql->execute();
    $result = $sql->get_result();

    if($result->num_rows > 0){
        $user = $result->fetch_assoc();
        return json_encode($user);
    }
    else {
        http_response_code(404);
        return json_encode(array("message" => "User not found"));
    }
}

function getUserReviews($conn, $id){
    $sql = $conn->prepare("SELECT u.username, r.rating, r.message 
    FROM users u INNER JOIN reviews r
    ON u.id = r.user_id WHERE u.id = ?");
    $sql->bind_param('i', $id);
    $sql->execute();

    $result = $sql->get_result();

    $reviews = array();
    while($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }

    if (count($reviews) > 0) {
        return json_encode($reviews);
    } else {
        http_response_code(404);
        return json_encode(array("message" => "No reviews found for this user"));
    }
}

function getActiveUsers($conn) {
    $sql = $conn->prepare("SELECT u.username, COUNT(r.id) AS Ertekelesek_szama
    FROM users u INNER JOIN reviews r
    ON u.id = r.user_id 
    GROUP BY u.username
    HAVING COUNT(r.id) > 2"
    );
    $sql->execute();

    $result = $sql->get_result();

    $actives = array();
    while($row = $result->fetch_assoc()) {
        $actives[] = $row;
    }

    if (count($actives) > 0) {
        return json_encode($actives);
    } else {
        http_response_code(404);
        return json_encode(array("message" => "No active users"));
    }
}

function createUser($conn, $data){
    if (!isset($data['username'], $data['password'])) {
    http_response_code(400);
    return json_encode(array("message" => "Missing required fields"));
    }

    $username = $data['username'];
    $password = $data['password'];

    $sql = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $sql->bind_param('s', $username);
    $sql->execute();

    $result = $sql->get_result();
    if ($result->num_rows > 0) {
        http_response_code(409);
        return json_encode(array("message" => "Username already exists"));
    }

    $sql2 = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $sql2->bind_param('ss', $username, $password);

    if($sql2->execute()){
        $user_id = $conn->insert_id;
        http_response_code(201);
        return json_encode(array("message" => "User created successfully", "user_id" => $user_id));
    }
    else {
        http_response_code(500);
        return json_encode(array("message" => "Error creating user", "error" => $sql2->error));
    }
}

function updateUser($conn, $data){
    if(!isset($data['id']) || !is_numeric($data['id'])){
        http_response_code(400);
        return json_encode(array("message" => "Must send a valid numeric id"));
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param('i', $data['id']);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 0){
        http_response_code(404);
        return json_encode(array("message" => "User not found"));
    }

    $user = $result->fetch_assoc();

    $username = isset($data['username']) ? $data['username'] : $user['username'];
    $password = isset($data['password']) ? $data['password'] : $user['password'];

    $update = $conn->prepare("UPDATE users SET username = ?, password = ? WHERE id = ?");
    $update->bind_param('ssi', $username, $password, $data['id']);

    if($update->execute()){
        return json_encode(array("message" => "User updated"));
    } else {
        http_response_code(500);
        return json_encode(array("message" => "Error updating user", "error" => $update->error));
    }
}

function deleteUser($conn, $id){
    if(!is_numeric($id)){
        http_response_code(400);
        return json_encode(array("message" => "Invalid id"));
    }

    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param('i', $id);

    if($stmt->execute()){
        if($stmt->affected_rows > 0){
            return json_encode(array("message" => "User deleted"));
        } else {
            http_response_code(404);
            return json_encode(array("message" => "User not found"));
        }
    } else {
        http_response_code(500);
        return json_encode(array("message" => "Error deleting user", "error" => $stmt->error));
    }
}

?>