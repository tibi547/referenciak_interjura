<?php
require_once "db.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if ($username === '' || $password === '') {
        header("Location: login_form.php?error=empty");
        exit;
    }

    $sql = $conn->prepare("SELECT id FROM users WHERE username = ? AND password = ?");
    $sql->bind_param("ss", $username, $password);
    $sql->execute();

    $result = $sql->get_result()->fetch_assoc();

    if ($result === null) {
        header("Location: login_form.php?error=invalid");
        exit;
    } else {
        $_SESSION["id"] = $result["id"];
        header("Location: index.php");
        exit;
    }
} else {
    header("Location: login_form.php?error=unauthorized");
    exit;
}
?>

