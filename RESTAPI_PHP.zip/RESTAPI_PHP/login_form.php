<?php
$error = isset($_GET['error']) ? $_GET['error'] : '';
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Bejelentkezés</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">

<div class="card shadow p-4" style="width: 100%; max-width: 400px;">
    <h2 class="text-center mb-4">Bejelentkezés</h2>

    <?php if ($error === 'empty'): ?>
        <div class="alert alert-warning" role="alert">
            Kérlek, töltsd ki az összes mezőt!
        </div>
    <?php elseif ($error === 'invalid'): ?>
        <div class="alert alert-danger" role="alert">
            Nincs ilyen felhasználó vagy rossz jelszó!
        </div>
    <?php elseif ($error === 'unauthorized'): ?>
        <div class="alert alert-info" role="alert">
            Kérlek, használd a bejelentkezési űrlapot!
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <div class="mb-3">
            <label for="username" class="form-label">Felhasználónév</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Jelszó</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Bejelentkezés</button>
    </form>
</div>

</body>
</html>
