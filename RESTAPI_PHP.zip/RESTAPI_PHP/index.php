<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anime értékelő</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <?php
    session_start();
    if (!isset($_SESSION["id"])) {
        header('Location: login_form.php');
        exit;
    }
    ?>

    <div class="container py-3">
        <?php include_once 'navbar.php'; ?>

        <div class="card mb-3">
            <div class="card-body">
                <p class="mb-0">Bejelentkezett felhasználó ID: <strong><?= $_SESSION["id"] ?></strong></p>
            </div>
        </div>
    </div>
    
</body>
</html>
