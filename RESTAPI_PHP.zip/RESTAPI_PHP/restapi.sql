CREATE DATABASE restapi;
USE restapi;

CREATE TABLE users
(
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(20) NOT NULL UNIQUE,
  password VARCHAR(20) NOT NULL
);

CREATE TABLE animes 
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    genre VARCHAR(255),
    year YEAR
);

CREATE TABLE reviews
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    anime_id INT,
    rating ENUM('1','2','3','4','5'),
    message VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (anime_id) REFERENCES animes(id) ON DELETE CASCADE
);

INSERT INTO users (username, password) VALUES ('tibi547', 'abcdgf'),
('dodge', 'jelszo'),
('!krisz1337', 'aaaaaa'),
('noriko', 'senpai'),
('toltt', 'ghjdmad');

INSERT INTO animes (title, genre, year) VALUES ('Dragon Ball Z', 'akció', 1989),
('Naruto', 'akció', 2002),
('Yu Yu Hakusho', 'akció', 1992),
('Death Note', 'krimi', 2006),
('Code Geass', 'sci-fi', 2006),
('Cowboy Bebop', 'sci-fi', 1998),
('Detective Conan', 'krimi', 1996),
('Berserk', 'horror', 1997),
('Monster', 'horror', 2004),
('Gundam', 'sci-fi', 1989);

INSERT INTO reviews (user_id, anime_id, rating, message)
VALUES 
(1, 1, '5', 'Nagyon király volt!'),
(2, 2, '4', 'Naruto gyerekkorom része'),
(3, 3, '5', 'Yu Yu Hakusho egy underrated klasszikus'),
(1, 2, '3', 'Naruto túl hosszú lett'),
(2, 1, '4', 'DBZ mindig nosztalgikus'),
(5, 5, '5', 'Tízpertíz'),
(4, 9, '3', 'Nem az én lelkivilágomnak való ToT');


