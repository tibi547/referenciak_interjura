<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "restapi";

$conn = new mysqli($server, $username, $password, $db);

if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}
?>